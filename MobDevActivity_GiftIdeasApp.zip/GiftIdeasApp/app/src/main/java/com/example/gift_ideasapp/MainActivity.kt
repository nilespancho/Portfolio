package com.example.gift_ideasapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import com.example.gift_ideasapp.databinding.ActivityMainBinding
import com.google.android.material.chip.Chip

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val male : Chip = findViewById(R.id.maleChip)
        val female : Chip = findViewById(R.id.femaleChip)
        val button : Button = findViewById(R.id.button)

        val intent = Intent(this, SecondActivity::class.java)

        button.setOnClickListener {
            if (male.isChecked){
                Toast.makeText(this, "Selected Male", Toast.LENGTH_SHORT).show()
                intent.putExtra("genderSelection", male.text)
                startActivity(intent)
            }
            else if (female.isChecked){
                Toast.makeText(this, "Selected Female", Toast.LENGTH_SHORT).show()
                intent.putExtra("genderSelection", female.text)
                startActivity(intent)
            }
            else{
                Toast.makeText(this, "Select a Recipient", Toast.LENGTH_SHORT).show()
            }
        }
    }
}