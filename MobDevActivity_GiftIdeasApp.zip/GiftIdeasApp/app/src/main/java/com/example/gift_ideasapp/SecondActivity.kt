package com.example.gift_ideasapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.gift_ideasapp.databinding.ActivitySecondBinding
import com.google.android.material.chip.Chip

class SecondActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        val infant : Chip = findViewById(R.id.infantChip)
        val adolescent : Chip = findViewById(R.id.adolescentChip)
        val adult : Chip = findViewById(R.id.adultChip)
        val button : Button = findViewById(R.id.button2)

        val bundle : Bundle?  = intent.extras
        val gender = bundle?.getString("genderSelection")
        val intent = Intent(this, ThirdActivity::class.java)


        button.setOnClickListener {
            if (infant.isChecked){
                Toast.makeText(this, "Selected Infant", Toast.LENGTH_SHORT).show()

                intent.putExtra("categorySelection", infant.text)
                intent.putExtra("genderSelection", gender)
                startActivity(intent)
            }
            else if (adolescent.isChecked){
                Toast.makeText(this, "Selected Adolescent", Toast.LENGTH_SHORT).show()

                intent.putExtra("categorySelection", adolescent.text)
                intent.putExtra("genderSelection", gender)
                startActivity(intent)
            }
            else if (adult.isChecked){
                Toast.makeText(this, "Selected Adult", Toast.LENGTH_SHORT).show()

                intent.putExtra("categorySelection", adult.text)
                intent.putExtra("genderSelection", gender)
                startActivity(intent)
            }
            else{
                Toast.makeText(this, "Select a Section", Toast.LENGTH_SHORT).show()
            }
        }
    }
}