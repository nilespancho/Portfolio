package com.example.gift_ideasapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.gift_ideasapp.databinding.ActivityThirdBinding
import org.w3c.dom.Text

class ThirdActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_third)

        val item1 : TextView = findViewById(R.id.suggestion2)
        val item2 : TextView = findViewById(R.id.suggestion1)
        val item3 : TextView = findViewById(R.id.suggestion3)
        val selected : TextView = findViewById(R.id.selected)
        val truck : ImageView = findViewById(R.id.trucks)
        val blanket : ImageView = findViewById(R.id.blanket)
        val doll : ImageView = findViewById(R.id.doll)
        val baseball: ImageView = findViewById(R.id.baseball)
        val softball : ImageView = findViewById(R.id.softball)
        val tie : ImageView = findViewById(R.id.tie)
        val earrings : ImageView = findViewById(R.id.earrings)
        val watchmen : ImageView = findViewById(R.id.watch_men)
        val watchwomen : ImageView = findViewById(R.id.watch_women)
        val button : Button = findViewById(R.id.button3)

        val bundle : Bundle? = intent.extras
        val gender = bundle?.getString("genderSelection")
        val category = bundle?.getString("categorySelection")

        if (gender == "Male" && category == "Infant") {
            selected.text = "Suggestions for Male Infants"
            item1.text = "Toy Trucks"
            item2.text = "Blankets"
            truck.alpha = 1F
            blanket.alpha = 1F
            item1.alpha = 1F
            item2.alpha = 1F
        }
        else if (gender == "Male" && category == "Adolescent"){
            selected.text = "Suggestions for Male Adolescents"
            item3.text = "Baseball Jersey"
            baseball.alpha = 1F
            item3.alpha = 1F
        }
        else if (gender == "Male" && category == "Adult"){
            selected.text = "Suggestions for Male Adults"
            item1.text = "Tie"
            item2.text = "Watch"
            tie.alpha = 1F
            watchmen.alpha = 1F
            item1.alpha = 1F
            item2.alpha = 1F
        }
        else if (gender == "Female" && category == "Infant"){
            selected.text = "Suggestions for Female Infants"
            item1.text = "Doll"
            item2.text = "Blankets"
            doll.alpha = 1F
            blanket.alpha = 1F
            item1.alpha = 1F
            item2.alpha = 1F
        }
        else if (gender == "Female" && category == "Adolescent"){
            selected.text = "Suggestions for Female Adolescents"
            item3.text = "Softball Jersey"
            softball.alpha = 1F
            item3.alpha = 1F
        }
        else if (gender == "Female" && category == "Adult"){
            selected.text = "Suggestions for Female Adults"
            item1.text = "Earrings"
            item2.text = "Watch"
            earrings.alpha = 1F
            watchwomen.alpha = 1F
            item1.alpha = 1F
            item2.alpha = 1F
        }

        button.setOnClickListener {
            Toast.makeText(this, "Back to Home", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
    }
}