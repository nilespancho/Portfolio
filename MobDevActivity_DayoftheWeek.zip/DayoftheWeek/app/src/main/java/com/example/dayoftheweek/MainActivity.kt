package com.example.dayoftheweek

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import com.example.dayoftheweek.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val days = arrayOf<String>("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")


        val intent = Intent(this, SecondActivity::class.java)

        binding.button.setOnClickListener {
            val day = binding.editTextNumber2.text.toString()


            intent.putExtra("day", day)
            startActivity(intent)
        }

    }
}