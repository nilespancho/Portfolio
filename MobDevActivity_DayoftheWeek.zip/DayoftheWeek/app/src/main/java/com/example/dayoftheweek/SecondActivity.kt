package com.example.dayoftheweek

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.ActionBar
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import com.example.dayoftheweek.databinding.ActivitySecondBinding

class SecondActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivitySecondBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val input = intent.getStringExtra("day")
        val array = arrayOf<String>("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")


        if (input == "1"){
            binding.textView2.text = array[0]
            binding.background.setBackgroundResource(R.color.monday)
        }
        else if (input == "2"){
            binding.textView2.text = array[1]
            binding.background.setBackgroundResource(R.color.tuesday)
        }
        else if (input == "3"){
            binding.textView2.text = array[2]
            binding.background.setBackgroundResource(R.color.wednesday)
        }
        else if (input == "4"){
            binding.textView2.text = array[3]
            binding.background.setBackgroundResource(R.color.thursday)
        }
        else if (input == "5"){
            binding.textView2.text = array[4]
            binding.background.setBackgroundResource(R.color.friday)
        }
        else if (input == "6"){
            binding.textView2.text = array[5]
            binding.background.setBackgroundResource(R.color.saturday)
        }
        else if (input == "7"){
            binding.textView2.text = array[6]
            binding.background.setBackgroundResource(R.color.sunday)
        }
        else{
            binding.textView2.text ="Invalid"
            binding.background.setBackgroundResource(R.color.invalid)
        }
    }
}