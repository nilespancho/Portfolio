package com.example.quoteoftheday

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val quotes = arrayOf("Try and try until you succeed", "Never give up", "Freedom means the opportunity to be what we never thought to be", "To love abundantly is to live abundantly, and to love forever is to live forever," +
                "To draw you must close your eyes and sing", "Go forth and open the sky, and list to Nature's teachings", "Give me liberty or give me death", "Go for it now. The future is is promised to no one" +
                "Everyday bring new choices", "A day without laughter is a day wasted")
        val generate : ImageButton = findViewById(R.id.generateButton)
        val dispQuote : TextView = findViewById(R.id.textView2)

        generate.setOnClickListener {
            val randomQuote = Random.nextInt(quotes.count())
            val temp = randomQuote

            if (randomQuote == temp){
                val randomQuote2 = Random.nextInt(quotes.count())
                dispQuote.text = quotes[randomQuote2]
            }
            else{
                dispQuote.text = quotes[randomQuote]
            }
        }

    }
}