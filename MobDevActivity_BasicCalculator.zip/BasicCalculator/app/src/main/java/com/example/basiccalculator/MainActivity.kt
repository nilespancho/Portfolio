package com.example.basiccalculator

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.annotation.Nullable

class MainActivity : AppCompatActivity() {

    lateinit var result : TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val x : EditText = findViewById(R.id.firstNumber)
        val y : EditText = findViewById(R.id.secondNumber)
        val add : Button = findViewById(R.id.addButton)
        val sub : Button = findViewById(R.id.subButton)
        val mul : Button = findViewById(R.id.mulButton)
        val div : Button = findViewById(R.id.divButton)

        result = findViewById(R.id.textView)

        add.setOnClickListener {
            val num1 = x.text.toString().toFloat()
            val num2 = y.text.toString().toFloat()
            addition(num1,num2)
        }

        sub.setOnClickListener {
            val num1 = x.text.toString().toFloat()
            val num2 = y.text.toString().toFloat()
            subtraction(num1,num2)
        }

        mul.setOnClickListener {
            val num1 = x.text.toString().toFloat()
            val num2 = y.text.toString().toFloat()
            multiplication(num1,num2)
        }

        div.setOnClickListener {
            val num1 = x.text.toString().toFloat()
            val num2 = y.text.toString().toFloat()
            division(num1,num2)
        }

    }

    private fun addition(num1: Float, num2: Float) {
        val sum = num1 + num2
        result.text = sum.toString()
    }

    private fun subtraction(num1: Float, num2: Float) {
        val diff = num1 - num2
        result.text = diff.toString()
    }

    private fun multiplication(num1: Float, num2: Float) {
        val prod = num1 * num2
        result.text = prod.toString()
    }

    private fun division(num1: Float, num2: Float) {
        val quo = num1 / num2
        result.text = quo.toString()
    }
}