package com.example.favenbateam

import android.media.Image
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.Switch
import android.widget.TextView
import com.google.android.material.button.MaterialButtonToggleGroup

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val nba : ImageView = findViewById(R.id.nbaPic)
        val lakersPic : ImageView = findViewById(R.id.lakersPic)
        val celticsPic : ImageView = findViewById(R.id.celticsPic)
        val warriorsPic : ImageView = findViewById(R.id.warriorsPic)
        val lakersButton : Button = findViewById(R.id.lakersButton)
        val celticsButton : Button = findViewById(R.id.celticsButton)
        val warriorsButton : Button = findViewById(R.id.warriorsButton)
        val lakersCount : TextView = findViewById(R.id.lakersCount)
        val celticsCount : TextView = findViewById(R.id.celticsCount)
        val warriorsCount : TextView = findViewById(R.id.warriorsCount)
        val switch : Switch = findViewById(R.id.switch2)


        switch.setOnCheckedChangeListener { _, isChecked ->
            if(isChecked){
                var lakers = 0
                var celtics = 0
                var warriors = 0

                lakersButton.setOnClickListener {
                    lakers++
                    nba.alpha = 0F
                    lakersPic.alpha = 1F
                    celticsPic.alpha = 0F
                    warriorsPic.alpha = 0F
                    lakersCount.text = "$lakers"
                }

                celticsButton.setOnClickListener{
                    celtics++
                    nba.alpha = 0F
                    lakersPic.alpha = 0F
                    celticsPic.alpha = 1F
                    warriorsPic.alpha = 0F
                    celticsCount.text = "$celtics"
                }

                warriorsButton.setOnClickListener {
                    warriors++
                    nba.alpha = 0F
                    lakersPic.alpha = 0F
                    celticsPic.alpha = 0F
                    warriorsPic.alpha = 1F
                    warriorsCount.text = "$warriors"
                }
            }
            else{
                var reset = 0

                nba.alpha = 1F
                lakersPic.alpha = 0F
                celticsPic.alpha = 0F
                warriorsPic.alpha = 0F

                lakersCount.text = "$reset"
                celticsCount.text = "$reset"
                warriorsCount.text = "$reset"
            }
        }


    }
}