package com.example.mixing_colorapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import com.google.android.material.chip.Chip


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val red : Chip = findViewById(R.id.redBox)
        val green : Chip = findViewById(R.id.greenBox)
        val blue : Chip = findViewById(R.id.blueBox)
        val view : Button = findViewById(R.id.viewButton)

        val intent = Intent(this, SecondActivity::class.java)

        view.setOnClickListener {
            if (red.isChecked && green.isChecked && blue.isChecked){
                intent.putExtra("redCheck", red.text)
                intent.putExtra("greenCheck", green.text)
                intent.putExtra("blueCheck", blue.text)
                startActivity(intent)
            }
            else if (red.isChecked && green.isChecked){
                intent.putExtra("redCheck", red.text)
                intent.putExtra("greenCheck", green.text)
                intent.putExtra("blueCheck", "Blank")
                startActivity(intent)
            }
            else if (red.isChecked && blue.isChecked){
                intent.putExtra("redCheck", red.text)
                intent.putExtra("greenCheck", "Blank")
                intent.putExtra("blueCheck", blue.text)
                startActivity(intent)
            }
            else if(red.isChecked){
                intent.putExtra("redCheck", red.text)
                intent.putExtra("greenCheck", "Blank")
                intent.putExtra("blueCheck", "Blank")
                startActivity(intent)
            }
            else if (green.isChecked && blue.isChecked){
                intent.putExtra("redCheck", "Blank")
                intent.putExtra("greenCheck", green.text)
                intent.putExtra("blueCheck", blue.text)
                startActivity(intent)
            }
            else if (green.isChecked){
                intent.putExtra("redCheck", "Blank")
                intent.putExtra("greenCheck", green.text)
                intent.putExtra("blueCheck", "Blank")
                startActivity(intent)
            }
            else if (blue.isChecked){
                intent.putExtra("redCheck", "Blank")
                intent.putExtra("greenCheck", "Blank")
                intent.putExtra("blueCheck", blue.text)
                startActivity(intent)
            }
            else{
                intent.putExtra("redCheck", "Blank")
                intent.putExtra("greenCheck", "Blank")
                intent.putExtra("blueCheck", "Blank")
                startActivity(intent)
            }
        }
    }
}