package com.example.mixing_colorapp

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout

class SecondActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        val text: TextView = findViewById(R.id.textView2)
        val background: ConstraintLayout = findViewById(R.id.background)
        val button: Button = findViewById(R.id.button)

        val bundle: Bundle? = intent.extras
        val r = bundle?.getString("redCheck")
        val g = bundle?.getString("greenCheck")
        val b = bundle?.getString("blueCheck")


        if (r == "Red" && g == "Green" && b == "Blue"){
            Toast.makeText(this, "White", Toast.LENGTH_SHORT).show()
            background.setBackgroundColor(Color.WHITE)
        }
        else if (r == "Red" && g == "Green" && b == "Blank"){
            Toast.makeText(this, "Yellow", Toast.LENGTH_SHORT).show()
            background.setBackgroundColor(Color.YELLOW)
        }
        else if (r == "Red" && g == "Blank" && b == "Blue"){
            Toast.makeText(this, "Magenta", Toast.LENGTH_SHORT).show()
            background.setBackgroundColor(Color.MAGENTA)
        }
        else if (r == "Red" && g == "Blank" && b == "Blank"){
            Toast.makeText(this, "Red", Toast.LENGTH_SHORT).show()
            background.setBackgroundColor(Color.RED)
        }
        else if (r == "Blank" && g == "Green" && b == "Blue"){
            Toast.makeText(this, "Cyan", Toast.LENGTH_SHORT).show()
            background.setBackgroundColor(Color.CYAN)
        }
        else if (r == "Blank" && g == "Green" && b == "Blank"){
            Toast.makeText(this, "Green", Toast.LENGTH_SHORT).show()
            background.setBackgroundColor(Color.GREEN)
        }
        else if (r == "Blank" && g == "Blank" && b == "Blue"){
            Toast.makeText(this, "Blue", Toast.LENGTH_SHORT).show()
            background.setBackgroundColor(Color.BLUE)
        }
        else{
            Toast.makeText(this, "Black", Toast.LENGTH_SHORT).show()
            background.setBackgroundColor(Color.BLACK)
        }

        button.setOnClickListener {
            Toast.makeText(this, "Mix Again", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

    }
}
