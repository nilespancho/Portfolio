package com.example.side_dish_recommender

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val burger : Chip = findViewById(R.id.burgerChip)
        val pasta : Chip = findViewById(R.id.pastaChip)
        val chicken : Chip = findViewById(R.id.chickenChip)
        val fries : ImageView = findViewById(R.id.fries)
        val breadsticks : ImageView = findViewById(R.id.breadsticks)
        val vegetables : ImageView = findViewById(R.id.vegetables)
        val side : TextView = findViewById(R.id.sideDish)
        val rec : TextView = findViewById(R.id.textView3)

        burger.setOnClickListener{
            side.text = "Fries"
            rec.alpha = 1F
            side.alpha = 1F
            fries.alpha = 1F
            breadsticks.alpha = 0F
            vegetables.alpha = 0F
            Toast.makeText(this, "You Selected Burger", Toast.LENGTH_SHORT).show()
        }

        pasta.setOnClickListener {
            side.text = "Bread Sticks"
            rec.alpha = 1F
            side.alpha = 1F
            fries.alpha = 0F
            breadsticks.alpha = 1F
            vegetables.alpha = 0F
            Toast.makeText(this, "You Selected Pasta", Toast.LENGTH_SHORT).show()
        }

        chicken.setOnClickListener {
            side.text = "Vegetable Stir Fry"
            rec.alpha = 1F
            side.alpha = 1F
            fries.alpha = 0F
            breadsticks.alpha = 0F
            vegetables.alpha = 1F
            Toast.makeText(this, "You Selected Orange Chicken", Toast.LENGTH_SHORT).show()
        }

    }
}