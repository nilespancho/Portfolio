package com.example.bmicalculator

import android.media.Image
import android.opengl.Visibility
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import java.math.RoundingMode
import java.text.DecimalFormat

class MainActivity : AppCompatActivity() {

    lateinit var status : TextView
    lateinit var value : TextView
    lateinit var underW : ImageView
    lateinit var normW : ImageView
    lateinit var overW : ImageView
    lateinit var obsW : ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val w : EditText = findViewById(R.id.weightInput)
        val h : EditText = findViewById(R.id.heightInput)
        val eval: Button = findViewById(R.id.button)

        status = findViewById(R.id.textView)
        value = findViewById(R.id.textView2)
        underW = findViewById(R.id.underWeight)
        normW = findViewById(R.id.normalWeight)
        overW = findViewById(R.id.overWeight)
        obsW = findViewById(R.id.obeseWeight)

        eval.setOnClickListener {
            val weight = w.text.toString().toFloat()
            val height = h.text.toString().toFloat()
            evaluateBMI(weight, height)
        }
    }

    private fun evaluateBMI(weight: Float, height: Float) {
        val result = (weight / (height * height))

        if(result < 18.5){
            status.text = "Underweight"
            underW.alpha = 1F
            normW.alpha = 0F
            overW.alpha = 0F
            obsW.alpha = 0F
        }
        else if(result >= 18.5 && result <= 24.9){
            status.text = "Normal"
            underW.alpha = 0F
            normW.alpha = 1F
            overW.alpha = 0F
            obsW.alpha = 0F
        }
        else if(result >= 25 && result <= 30){
            status.text = "Overweight"
            underW.alpha = 0F
            normW.alpha = 0F
            overW.alpha = 1F
            obsW.alpha = 0F
        }
        else{
            status.text = "Obese"
            underW.alpha = 0F
            normW.alpha = 0F
            overW.alpha = 0F
            obsW.alpha = 1F
        }

        val format = DecimalFormat("#.##")
        format.roundingMode = RoundingMode.UP
        val display = format.format(result)
        value.text = display.toString()


    }
}