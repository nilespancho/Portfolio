package com.example.wordyapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import com.example.wordyapp.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //val binding = ActivityMainBinding.inflate(layoutInflater)
        //setContentView(binding.root)

        val name : EditText = findViewById(R.id.nameInput)
        val disp : TextView = findViewById(R.id.nameDisplay)
        val add : Button = findViewById(R.id.addName)
        val clear : Button = findViewById(R.id.clearName)
        val ascend : RadioButton = findViewById(R.id.ascOrder)
        val descend : RadioButton = findViewById(R.id.desOrder)

        val nameInput = mutableListOf(name.text.toString())

        add.setOnClickListener {
            if (name.length()!=0){
                nameInput.add(name.text.toString())
                disp.text = ""

                for (i in 0 until nameInput.size){
                    disp.append(nameInput[i])
                    disp.append("\n")
                }
            }
        }

        clear.setOnClickListener {
            nameInput.clear()
            disp.text = ""
        }

        ascend.setOnClickListener {
            nameInput.sort()
            disp.text = ""

            for (i in 0 until nameInput.size){
                disp.append(nameInput[i])
                disp.append("\n")
            }
        }

        descend.setOnClickListener {
            nameInput.sortDescending()
            disp.text = ""

            for (i in 0 until nameInput.size){
                disp.append(nameInput[i])
                disp.append("\n")
            }
        }
    }
}